from django.urls import path
from . import views

urlpatterns = [
    path('hasiera/', views.home, name='home'),
    path('', views.invitado, name='invitado'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('guest/', views.invitado, name='invitado'),
    path('guestEmaitzak/', views.emaitzak_invitado, name='invitadoEmaitzak'),
    path('emaitzak/', views.lortu_emaitza, name='emaitzak'),
    path('history/', views.kontsultak_ikusi, name='history'),
    path('logout/', views.user_logout, name='logout'),
    path('kontsulta/delete/<int:kontsulta_id>/', views.delete_kontsulta, name='delete_kontsulta'),
    path('api/emaitzak/', views.emaitzak_invitado_api, name='emaitzak_api'),
    path('emaitzak/page/', views.render_emaitzak_page, name='emaitzak_page'),

    
]
