import shutil
from django.conf import settings
from django.http import HttpResponse
from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from .models import Kontsultak, EmaitzaFormatua
from .forms import LematizationInvitado, RegisterForm, LematizationForm, FileFieldForm
from .lematizatu import lemmatize_text
from .laguntzaileak import testu_sarrera, output_bateratua, output_bateratua_fitxategiak, save_uploaded_file, karpeta_sortu, doc_sarrera, txukundu_txt, txukundu_conll, txukundu_csv, txukundu_json, txukundu_pdf
from concurrent.futures import ThreadPoolExecutor
import os
from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator
from django.utils.translation import gettext as _
from django.db.models import Q
from datetime import datetime
from django.shortcuts import get_object_or_404

TSV_FITXATEGIAK = "lematizatzeko_fitxategiak"
OUTPUT = "output"
EMAITZAK = "emaitzak"
FITXATEGIAK = "fitxategi_guztiak"
OUTPUT_2 = "output_2"


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        form2 = LematizationForm()
        form3 = FileFieldForm()
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return render(request, 'home.html', {'form': form2, 'form2': form3})
        else:
            error = _("Sartutako datuekin ez da posible erregistroa egitea.")
            return render(request, 'register.html', {'form': form, 'error': error}) 
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        form2 = LematizationForm()
        form3 = FileFieldForm()
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return render(request, 'home.html', {'form': form2, 'form2': form3})
        else:
            error = _("Erabiltzaile izena edo pasahitza ez dira zuzenak.")
            return render(request, 'login.html', {'form': form, 'error': error})
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

@login_required
def user_logout(request):
    logout(request)
    form = RegisterForm()
    return render(request, 'register.html', {'form': form})

@login_required
def home(request):
    form2 = LematizationForm()
    form3 = FileFieldForm()
    return render(request, 'home.html', {'form': form2, 'form2': form3})

def invitado(request):
    form2 = LematizationForm()
    form3 = FileFieldForm()
    return render(request, 'invHome.html', {'form': form2, 'form2': form3})

@login_required
def lortu_emaitza(request):
    karpeta_sortu(FITXATEGIAK)
    karpeta_sortu(TSV_FITXATEGIAK)
    karpeta_sortu(OUTPUT)
    karpeta_sortu(EMAITZAK)
    karpeta_sortu(OUTPUT_2)
    karpeta_sortu(settings.STATIC_MEDIA_EMAITZAK)
    karpeta_sortu(settings.STATIC_MEDIA_FITXATEGIAK)
    if request.method == 'POST':
        form2 = FileFieldForm(request.POST, request.FILES)
        form = LematizationForm(request.POST)
        erroreak = []
        if form.is_valid():
            sOpt = form.cleaned_data.get('option')
            iOpts = form.cleaned_data.get('options')
            if sOpt == 'text':
                # testua tratatu
                testua = form.cleaned_data.get('text_area')
                if not testua.strip():
                    e1 = _("Ez duzu lematizatzeko edukirik sartu.")
                    erroreak.append(e1)

                testu_sarrera(testua)
                lematizatzeko_fitxateagiak = os.listdir(TSV_FITXATEGIAK)
                
                for lem_f in lematizatzeko_fitxateagiak:
                    lemmatize_text(os.path.join(TSV_FITXATEGIAK, lem_f))
                    
            
                output_bateratua()
                outputFin = os.listdir(OUTPUT)[0]
                testua_output = ""
                if not iOpts:
                    e2 = _("Aukeratu emaitza nola jaso nahi duzun.")
                    erroreak.append(e2)
                else:
                    if '1' in iOpts:
                        txukundu_txt(os.path.join(OUTPUT, outputFin))
                        with open(os.path.join(EMAITZAK, 'finalOut.txt'), 'r') as f:
                            testua_output = f.read()
                    if '2' in iOpts:
                        txukundu_pdf(os.path.join(OUTPUT, outputFin))
                    if '3' in iOpts:
                        txukundu_csv(os.path.join(OUTPUT, outputFin))
                    if '4' in iOpts:
                        txukundu_conll(os.path.join(OUTPUT, outputFin))
                    if '5' in iOpts:
                        txukundu_json(os.path.join(OUTPUT, outputFin))
                
                emaitzaFitxategiak = []
                emaitzaFitxategiak2 = []
                emaitzak_files = os.listdir(EMAITZAK)

                for fileN in emaitzak_files:
                    emaitzaFitxategiak2.append(fileN)
               
                for file_name in emaitzak_files:
                    source_path = os.path.join(EMAITZAK, file_name)
                    destination_path = os.path.join(settings.STATIC_MEDIA_EMAITZAK, file_name)

                    if os.path.isfile(source_path):
                       
                        shutil.move(source_path, destination_path)
                       
                        emaitzaFitxategiak.append(f'media/emaitzak/{file_name}')
                emaitzaF = zip(emaitzaFitxategiak, emaitzaFitxategiak2)
                if not erroreak:
                    emaitza_formatua = EmaitzaFormatua(emaitza = iOpts)
                    emaitza_formatua.save()
                    if emaitza_formatua:
                        kontsulta = Kontsultak(
                            user=request.user,  
                            inputText=testua,   
                            soluzioa=testua_output, 
                            emaitzaFormatua=emaitza_formatua  
                        )
                        kontsulta.save()
                    return render(request, 'emaitzak.html', {'testua':testua, 'testua_output': testua_output, 'options':iOpts, 'emaitzaFitxategiak':emaitzaF, 'sarreraMota':sOpt})     
            
            elif sOpt == 'upload' and form2.is_valid():
                files = request.FILES.getlist('file_field')
                if not files:
                    e3 = _("Ez duzu fitxategirik igo.")
                    erroreak.append(e3)
                else:
                    if not iOpts:
                        e4 = _("Aukeratu emaitza nola jaso nahi duzun.")
                        erroreak.append(e4)
                    else:

                        allowend_extensions = ['.pdf', '.txt', '.csv', '.tsv', '.docx']
                            
                        moved_files = [save_uploaded_file(file, FITXATEGIAK) for file in files]
                        moved_files_2 = [save_uploaded_file(file, settings.STATIC_MEDIA_FITXATEGIAK) for file in files]

                        for mvFile in moved_files:
                            extension = os.path.splitext(mvFile)[1]
                            if extension.lower() not in allowend_extensions:
                                e8 = _("Solik testu fitxategiak onartzen dira.")
                                erroreak.append(e8)
                                form = LematizationForm()  
                                form2 = FileFieldForm()
                                return render(request, 'home.html', {'erroreak':erroreak, 'form': form, 'form2': form2})



                        for kont, moved_file in enumerate(moved_files, start=1):
                            doc_sarrera(moved_file)
                            
                            lematizatzeko_fitxateagiak = os.listdir(TSV_FITXATEGIAK)
                            for lem_f in lematizatzeko_fitxateagiak:
                                lemmatize_text(os.path.join(TSV_FITXATEGIAK, lem_f))
                            
                            output_bateratua_fitxategiak(kont)
                            karpeta_sortu(TSV_FITXATEGIAK)
                            karpeta_sortu(OUTPUT)

                        testua_output = ""
                       
                        fitxategiakOut2 = os.listdir(OUTPUT_2)
                        if len(files) > 1 and '1' in iOpts:
                            e5 = _("Fitxategi bat baino gehiago lematizatzea nahi baduzu, emaitza ezin duzu pantailan jaso.")
                            erroreak.append(e5)
                        elif len(files) == 1 and '1' in iOpts:
                            txukundu_txt(os.path.join(OUTPUT_2, fitxategiakOut2[0]))
                            txtEmaitza = os.listdir(EMAITZAK)[0]
                            with open(os.path.join(EMAITZAK, txtEmaitza), 'r') as f:
                                testua_output = f.read()

                        if '2' in iOpts:
                            for fileOut2 in fitxategiakOut2:
                                txukundu_pdf(os.path.join(OUTPUT_2, fileOut2))
                        if '3' in iOpts:
                            for fileOut2 in fitxategiakOut2:
                                txukundu_csv(os.path.join(OUTPUT_2, fileOut2))
                        if '4' in iOpts:
                            for fileOut2 in fitxategiakOut2:
                                txukundu_conll(os.path.join(OUTPUT_2, fileOut2))
                        if '5' in iOpts:
                            for fileOut2 in fitxategiakOut2:
                                txukundu_json(os.path.join(OUTPUT_2, fileOut2))

                        
                        emaitzaFitxategiak = []
                        emaitzaFitxategiak2 = []
                        emaitzak_files = os.listdir(EMAITZAK)
                        
                        for fileN in emaitzak_files:
                            emaitzaFitxategiak2.append(fileN)
                        for file_name in emaitzak_files:
                            source_path = os.path.join(EMAITZAK, file_name)
                            destination_path = os.path.join(settings.STATIC_MEDIA_EMAITZAK, file_name)
                            if os.path.isfile(source_path):
                                shutil.move(source_path, destination_path)
                                emaitzaFitxategiak.append(f'media/emaitzak/{file_name}')
                        
                        emaitzaF = zip(emaitzaFitxategiak, emaitzaFitxategiak2)
                        if not erroreak:
                            return render(request, 'emaitzak.html', {'testua_output': testua_output, 'emaitzaFitxategiak': emaitzaF, 'options':iOpts, 'sarrera_files':moved_files_2, 'sarreraMota':sOpt})

       
            else: #form2 is not valid
                e6 = _("Formulario okerra.")
                erroreak.append(e6)
        else: #form is not valid
            e7 = _("Formulario okerra.")
            erroreak.append(e7)
    else: 
        form = LematizationForm()  
        form2 = FileFieldForm()

    if erroreak:
        form = LematizationForm()  
        form2 = FileFieldForm()
        return render(request, 'home.html', {'erroreak':erroreak, 'form': form, 'form2': form2})
    
    return render(request, 'emaitzak.html')

def emaitzak_invitado(request):
    karpeta_sortu(FITXATEGIAK)
    karpeta_sortu(TSV_FITXATEGIAK)
    karpeta_sortu(OUTPUT)
    karpeta_sortu(EMAITZAK)
    karpeta_sortu(OUTPUT_2)
    karpeta_sortu(settings.STATIC_MEDIA_EMAITZAK)
    karpeta_sortu(settings.STATIC_MEDIA_FITXATEGIAK)
    if request.method == 'POST':
        form = LematizationInvitado(request.POST)
        erroreak = []
        print("post")
        if form.is_valid():
            print("form")
            # testua tratatu
            testua = form.cleaned_data.get('text_area')
            if not testua.strip():
                e1 = _("Ez duzu lematizatzeko edukirik sartu.")
                erroreak.append(e1)

            testu_sarrera(testua)
            lematizatzeko_fitxateagiak = os.listdir(TSV_FITXATEGIAK)
            
            for lem_f in lematizatzeko_fitxateagiak:
                lemmatize_text(os.path.join(TSV_FITXATEGIAK, lem_f))
                                
            output_bateratua()
            outputFin = os.listdir(OUTPUT)[0]
            testua_output = ""

            txukundu_txt(os.path.join(OUTPUT, outputFin))
            with open(os.path.join(EMAITZAK, 'finalOut.txt'), 'r') as f:
                testua_output = f.read()
                                    
            if not erroreak:
                return render(request, 'invEmaitzak.html', {'testua':testua, 'testua_output': testua_output})     

    else:
        form = LematizationForm()  
    return render(request, 'invHome.html', { 'form': form})
    
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


@csrf_exempt
def emaitzak_invitado_api(request):
    if request.method == 'POST':
        try:
            
            data = json.loads(request.body)
            text = data.get('text_area', '')

            if not text.strip():
                return JsonResponse({'error': 'Ez duzu lematizatzeko edukirik sartu.'}, status=400)

            karpeta_sortu(FITXATEGIAK)
            karpeta_sortu(TSV_FITXATEGIAK)
            karpeta_sortu(OUTPUT)
            karpeta_sortu(EMAITZAK)
            karpeta_sortu(OUTPUT_2)
            karpeta_sortu(settings.STATIC_MEDIA_EMAITZAK)
            karpeta_sortu(settings.STATIC_MEDIA_FITXATEGIAK)

            testu_sarrera(text)
            lematizatzeko_fitxateagiak = os.listdir(TSV_FITXATEGIAK)

            for lem_f in lematizatzeko_fitxateagiak:
                lemmatize_text(os.path.join(TSV_FITXATEGIAK, lem_f))

            output_bateratua()
            outputFin = os.listdir(OUTPUT)[0]

            txukundu_txt(os.path.join(OUTPUT, outputFin))
            with open(os.path.join(EMAITZAK, 'finalOut.txt'), 'r') as f:
                testua_output = f.read()

            request.session['testua'] = text
            request.session['testua_output'] = testua_output

            return redirect('emaitzak_page')  

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data.'}, status=400)

    return JsonResponse({'error': 'Only POST method is allowed.'}, status=405)


def render_emaitzak_page(request):
    testua = request.session.get('testua', '')
    testua_output = request.session.get('testua_output', '')

    return render(request, 'invEmaitzak.html', {'testua': testua, 'testua_output': testua_output})


@login_required
def kontsultak_ikusi(request):
    query = request.GET.get('search', '')  
    sort_by = request.GET.get('sort_by', 'kontsulta_data') 
    order = request.GET.get('order', 'asc')  

    
    if order == 'desc':
        sort_by = f'-{sort_by}'  
    
    kontsultak_list = Kontsultak.objects.filter(user=request.user)

    if query:
        kontsultak_list = kontsultak_list.filter(
            Q(inputText__icontains=query) | 
            Q(kontsulta_data__icontains=query)
        )
    
    kontsultak_list = kontsultak_list.order_by(sort_by)

    paginator = Paginator(kontsultak_list, 10)
    page_number = request.GET.get('page')
    kontsultak = paginator.get_page(page_number)

    return render(request, 'historiala.html', {
        'kontsultak': kontsultak,
        'search': query,
        'sort_by': sort_by.lstrip('-'),  
        'order': order
    })

@login_required
def delete_kontsulta(request, kontsulta_id):
    kontsulta = get_object_or_404(Kontsultak, id=kontsulta_id, user=request.user)
    kontsulta.delete()
    return render(request, 'kontsulta_ezabatua.html', {'kontsulta': kontsulta})
    
    



#superuser:joanesADMIN || 12345678JA
