from django.db import models
from django.contrib.auth.models import User



class EmaitzaFormatua(models.Model):
    EMAITZA_NOLA_JASO = [
        ("1", "Pantailan erakutsi"),
        ("2", "Fitxategia pdf formatuan"),
        ("3", "Fitxategia csv formatuan"),
        ("4", "Fitxategia CoNLL formatuan"),
        ("5", "Fitxategia JSON formatuan"),
    ]
    emaitza = models.CharField(max_length=2, choices=EMAITZA_NOLA_JASO)
    


class Kontsultak(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='kontsultak')
    inputText = models.TextField()
    kontsulta_data = models.DateTimeField(auto_now_add=True)
    emaitzaFormatua = models.ForeignKey(EmaitzaFormatua, on_delete=models.CASCADE)
    soluzioa = models.TextField()  # Storing the lemmatized solution here
